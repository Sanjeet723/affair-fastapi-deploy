from fastapi import FastAPI
from schemas.input_schema import AffairInput
import joblib
import pandas as pd

app = FastAPI()

model = joblib.load("model/affair_model.pkl")
scaler = joblib.load("model/scaler.pkl")

@app.post("/predict")
def predict_affair(data: AffairInput):
    input_dict = data.dict()
    df = pd.DataFrame([input_dict])

    # One-hot encode manually
    df_encoded = pd.get_dummies(df, columns=[
        'rate_marriage', 'religious', 'occupation', 'occupation_husb', 'children', 'educ'
    ], drop_first=True)

    # Ensure all expected columns exist
    expected_cols = model.feature_names_in_
    for col in expected_cols:
        if col not in df_encoded.columns:
            df_encoded[col] = 0

    df_encoded = df_encoded[expected_cols]
    df_encoded[['age', 'yrs_married']] = scaler.transform(df_encoded[['age', 'yrs_married']])

    prediction = model.predict(df_encoded)[0]
    prob = model.predict_proba(df_encoded)[0][1]

    return {"affair_prediction": int(prediction), "confidence": round(prob, 2)}
