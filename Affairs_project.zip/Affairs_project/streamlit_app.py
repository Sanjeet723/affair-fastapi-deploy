import streamlit as st
import requests

st.title("💔 Affair Prediction App")

age = st.number_input("Age", min_value=18.0, max_value=100.0)
yrs_married = st.number_input("Years Married", min_value=0.0, max_value=50.0)
rate_marriage = st.selectbox("Rate Marriage", [1, 2, 3, 4, 5])
religious = st.selectbox("Religious Level", [1, 2, 3, 4])
occupation = st.selectbox("Occupation", [1, 2, 3, 4, 5, 6])
occupation_husb = st.selectbox("Husband's Occupation", [1, 2, 3, 4, 5, 6])
children = st.selectbox("Children", [0, 1])
educ = st.selectbox("Education Level", [9, 10, 11, 12, 13, 14, 15, 16])

if st.button("Predict"):
    payload = {
        "age": age,
        "yrs_married": yrs_married,
        "rate_marriage": rate_marriage,
        "religious": religious,
        "occupation": occupation,
        "occupation_husb": occupation_husb,
        "children": children,
        "educ": educ
    }

    response = requests.post("https://your-fastapi-url/predict", json=payload)
    result = response.json()

    st.success(f"Prediction: {'💔 Had Affair' if result['affair_prediction'] else '❤️ No Affair'}")
    st.write(f"Confidence: {result['confidence'] * 100:.2f}%")
