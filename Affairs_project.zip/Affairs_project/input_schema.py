from pydantic import BaseModel

class AffairInput(BaseModel):
    age: float
    yrs_married: float
    rate_marriage: int
    religious: int
    occupation: int
    occupation_husb: int
    children: int
    educ: int
